<?php

namespace App\Controllers;
use App\Models\TeamMember;

class Home extends BaseController
{

    public function index(): string
    {
        return view('section/header')
            .view('home_page')
            .view('section/footer');
    }
}
