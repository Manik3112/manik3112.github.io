# Koshish Family Website

## Using Code Ignitor as a Framework

CodeIgniter is a PHP full-stack web framework that is light, fast, flexible and secure.
More information can be found at the [official site](https://codeigniter.com).
